

#ifndef SPI_H_
#define SPI_H_



void SPI_task(void *pvParameters);


#endif /* SPI_H_ */
