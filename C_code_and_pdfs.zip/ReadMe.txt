The following are in the Appendix:
A C code for the Master Tiva written in Code Composer,
A VHDL code for the Slave written in Vivado 2023.02

And four of the PDFs, which are described in the rapport.